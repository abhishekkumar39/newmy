﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookMyShow_DAO
{
    public class Booking
    {
        public int BookingId { get; set; }
        public string? TheaterId { get; set; }
        public string? MovieId { get; set; }
        public string? BookingSeats { get; set; }
        public string? BookingStatus { get; set; }
        public decimal NetAmount { get; set; }
    }
}
