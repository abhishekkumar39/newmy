﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using BookMyShow_DAO;
using System.Security.Policy;
using System.Text;

namespace BookMyShow_MVC.Controllers
{
    public class AdminRegistartionsController : Controller
    {
        private readonly HttpClient _httpClient;
        public AdminRegistartionsController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5294/api/AdminRegistrations");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var adminregistartions = JsonConvert.DeserializeObject<List<AdminRegistartion>>(jsondata);
                return View(adminregistartions);
            }
            return View();
        }

        // GET: AdminsController/Details/5
        public async Task<IActionResult> GetAdminRegistartionDetails(int? id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/AdminRegistrations/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var adminregistartions = JsonConvert.DeserializeObject<AdminRegistartion>(jsondata);
                return View(adminregistartions);
            }
            return NotFound();
           
        }

        // GET: AdminsController/Create
        public ActionResult AddAdminRegistartionDetails()
        {
            return View();
        }

        // POST: AdminsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddAdminRegistartionDetails(AdminRegistartion adre)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5294/api/AdminRegistartions", adre);
            return RedirectToAction(nameof(Default));
        }

        // GET: AdminsController/Edit/5

        public async Task<IActionResult> UpdateAdminRegistartionDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/AdminRegistartions/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var adre = JsonConvert.DeserializeObject<AdminRegistartion>(jsondata);
                return View(adre);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateAdminRegistartionDetails(int id, AdminRegistartion adre)
        {
            if (id != adre.AdminRegistartionId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(adre);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5294/api/AdminRegistartions/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(adre);
        }
        // GET: AdminsController/Delete/5


        // POST: AdminsController/Delete/5
        public async Task<IActionResult> DeleteAdminRegistartionDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/AdminRegistartions/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var adre = JsonConvert.DeserializeObject<AdminRegistartion>(jsondata);
                return View(adre);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteAdminRegistartionDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5294/api/AdminRegistartions/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
        
    }
}
