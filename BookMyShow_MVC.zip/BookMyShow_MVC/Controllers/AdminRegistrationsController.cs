﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using BookMyShow_DAO;
using System.Text;
using System.Net;

namespace BookMyShow_MVC.Controllers
{
    public class AdminRegistrationsController : Controller
    {
        private readonly HttpClient _httpClient;
        public AdminRegistrationsController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(AdminRegistration admin)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/AdminRegistrations?{admin.AdminName}/{admin.Password}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index", "Home");
            }
            else if (response.StatusCode == HttpStatusCode.NotFound)
            {
                // Handle successful login logic here
                return RedirectToAction("Default", "Home");
            }
            else
            {
                ModelState.AddModelError("", "Invalid login attempt.");
            }

            return View(admin);
        }
        public IActionResult GetAdminRegistrationDetails()
        {
            return View();
        }

        [HttpPost]
        public IActionResult GetAdminRegistrationDetails(AdminRegistration admin)
        {
            if (ModelState.IsValid)
            {
                // Save user to the database
                return RedirectToAction("Default");
            }
            return View(admin);
        }
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5294/api/AdminRegistrations");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var admins = JsonConvert.DeserializeObject<List<AdminRegistration>>(jsondata);
                return View(admins);
            }
            return View();
        }

        public IActionResult AddAdminRegistrationDetails()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddAdminRegistrationDetails(AdminRegistration admin)
        {
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(admin);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync("http://localhost:5294/api/AdminRegistrations", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(admin);


        }

        public async Task<IActionResult> UpdateAdminRegistartionDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/AdminRegistrations/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var admin = JsonConvert.DeserializeObject<AdminRegistration>(jsondata);
                return View(admin);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateAdminRegistartionDetails(int id, AdminRegistration admin)
        {
            if (id != admin.AdminRegistrationId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(admin);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5294/api/AdminRegistrations/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(admin);
        }


        // GET: Admins/Delete/5
        // GET: Admins/RemoveAdmin/5
        public async Task<IActionResult> DeleteAdminRegistrationDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/AdminRegistrations/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var admin = JsonConvert.DeserializeObject<AdminRegistration>(jsondata);
                return View(admin);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteAdminRegistrationDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RemoveConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5294/api/AdminRegistrations/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}




