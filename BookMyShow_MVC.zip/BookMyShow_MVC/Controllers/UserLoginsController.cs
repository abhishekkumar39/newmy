﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;
namespace BookMyShow_MVC.Controllers

{
    public class UserLoginsController : Controller
    {
        private readonly HttpClient _httpClient;
        public UserLoginsController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5294/api/UserLogins");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var userLogins = JsonConvert.DeserializeObject<List<UserLogin>>(jsondata);
                return View(userLogins);
            }
            return View();
        }

        // GET: UserLoginsController/Details/5
         public async Task<IActionResult> GetUserLoginDetails(int? id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/UserLogins/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var ul = JsonConvert.DeserializeObject<UserLogin>(jsondata);
                return View(ul);
            }
            return NotFound();

        }

        // GET: AdminsController/Create
        public ActionResult AddUserLoginDetails()
        {
            return View();
        }

        // POST: AdminsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddUserLoginDetails(UserLogin ul)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5294/api/UserLogins", ul);
            return RedirectToAction(nameof(Default));
        }

        // GET: AdminsController/Edit/5

        public async Task<IActionResult> UpdateUserLoginDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/UserLogins/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var ul = JsonConvert.DeserializeObject<UserLogin>(jsondata);
                return View(ul);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateUserLoginDetails(int id, UserLogin ul)
        {
            if (id != ul.UserLoginId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(ul);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5294/api/UserLogins/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(ul);
        }
        // GET: AdminsController/Delete/5


        // POST: AdminsController/Delete/5
        public async Task<IActionResult> DeleteUserLoginDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/UserLogins/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var ul = JsonConvert.DeserializeObject<UserLogin>(jsondata);
                return View(ul);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteUserLoginDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5294/api/UserLogins/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}
