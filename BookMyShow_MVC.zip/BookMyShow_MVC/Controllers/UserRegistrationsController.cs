﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using BookMyShow_DAO;
using System.Text;
using System.Net;

namespace BookMyShow_MVC.Controllers
{
    public class UserRegistrationsController : Controller
    {
        private readonly HttpClient _httpClient;
        public UserRegistrationsController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(UserRegistration admin)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/UserRegistrations?{admin.UserName}/{admin.Password}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index", "Home");
            }
            else if (response.StatusCode == HttpStatusCode.NotFound)
            {
                // Handle successful login logic here
                return RedirectToAction("Default", "Home");
            }
            else
            {
                ModelState.AddModelError("", "Invalid login attempt.");
            }

            return View(admin);
        }
        public IActionResult GetUserRegistrationDetails()
        {
            return View();
        }

        [HttpPost]
        public IActionResult GetUserRegistrationDetails(UserRegistration admin)
        {
            if (ModelState.IsValid)
            {
                // Save user to the database
                return RedirectToAction("Default");
            }
            return View(admin);
        }
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5294/api/UserRegistrations");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var admins = JsonConvert.DeserializeObject<List<UserRegistration>>(jsondata);
                return View(admins);
            }
            return View();
        }

        public IActionResult AddUserRegistrationDetails()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddUserRegistrationDetails(UserRegistration admin)
        {
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(admin);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync("http://localhost:5294/api/UserRegistrations", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(admin);


        }

        public async Task<IActionResult> UpdateUserRegistrationDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/UserRegistrations/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var admin = JsonConvert.DeserializeObject<UserRegistration>(jsondata);
                return View(admin);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateUserRegistrationDetails(int id, UserRegistration admin)
        {
            if (id != admin.UserRegistrationId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(admin);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5294/api/UserRegistrations/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(admin);
        }


        // GET: Admins/Delete/5
        // GET: Admins/RemoveAdmin/5
        public async Task<IActionResult> DeleteUserRegistrationDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/UserRegistrations/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var admin = JsonConvert.DeserializeObject<UserRegistration>(jsondata);
                return View(admin);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteUserRegistrationDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RemoveConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5294/api/UserRegistrations/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}




