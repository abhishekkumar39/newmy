﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;
namespace BookMyShow_MVC.Controllers
{
    public class PaymentsController : Controller
    {
       
            private readonly HttpClient _httpClient;
            public PaymentsController(HttpClient httpClient)
            {
                _httpClient = httpClient;
            }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5294/api/Payments");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var payments = JsonConvert.DeserializeObject<List<Payment>>(jsondata);
                return View(payments);
            }
            return View();
        }

        // GET: PaymentsController/Details/5
        public async Task<IActionResult> GetPaymentDetails(int? id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Payments/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var admins = JsonConvert.DeserializeObject<Payment>(jsondata);
                return View(admins);
            }
            return NotFound();

        }

        // GET: AdminsController/Create
        public ActionResult AddAdminDetails()
        {
            return View();
        }

        // POST: AdminsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddAdminDetails(Admin ad)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5294/api/Admins", ad);
            return RedirectToAction(nameof(Default));
        }

        // GET: AdminsController/Edit/5

        public async Task<IActionResult> UpdateAdminDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Admins/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var ad = JsonConvert.DeserializeObject<Admin>(jsondata);
                return View(ad);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateAdminDetails(int id, Admin ad)
        {
            if (id != ad.AdminId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(ad);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5294/api/Admins/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(ad);
        }
        // GET: AdminsController/Delete/5


        // POST: AdminsController/Delete/5
        public async Task<IActionResult> DeleteAdminDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Admins/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var ad = JsonConvert.DeserializeObject<Admin>(jsondata);
                return View(ad);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteAdminDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5294/api/Admins/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}
