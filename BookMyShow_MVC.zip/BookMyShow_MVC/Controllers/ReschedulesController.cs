﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;
namespace BookMyShow_MVC.Controllers
{
    public class ReschedulesController : Controller
    {
        private readonly HttpClient _httpClient;
        public ReschedulesController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5294/api/Reschedules");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var reschedules = JsonConvert.DeserializeObject<List<Reschedule>>(jsondata);
                return View(reschedules);
            }
            return View();
        }

        // GET: ReschedulesController/Details/5
        public async Task<IActionResult> GetRescheduleDetails(int? id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Reschedules/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var re = JsonConvert.DeserializeObject<Reschedule>(jsondata);
                return View(re);
            }
            return NotFound();

        }

        // GET: AdminsController/Create
        public ActionResult AddRescheduleDetails()
        {
            return View();
        }

        // POST: AdminsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddRescheduleDetails(Reschedule re)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5294/api/Reschedules", re);
            return RedirectToAction(nameof(Default));
        }

        // GET: AdminsController/Edit/5

        public async Task<IActionResult> UpdateRescheduleDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Reschedules/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var re = JsonConvert.DeserializeObject<Reschedule>(jsondata);
                return View(re);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateRescheduleDetails(int id, Reschedule re)
        {
            if (id != re.RescheduleId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(re);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5294/api/Reschedules/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(re);
        }
        // GET: AdminsController/Delete/5


        // POST: AdminsController/Delete/5
        public async Task<IActionResult> DeleteRescheduleDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Reschedules/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var re = JsonConvert.DeserializeObject<Reschedule>(jsondata);
                return View(re);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteRescheduleDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5294/api/Reschedules/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}
