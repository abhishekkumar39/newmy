﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;
namespace BookMyShow_MVC.Controllers
{
    public class BookingsController : Controller
    {
           private readonly HttpClient _httpClient;
            public BookingsController(HttpClient httpClient)
            {
                _httpClient = httpClient;
            }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5294/api/Bookings");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var bookings = JsonConvert.DeserializeObject<List<Booking>>(jsondata);
                return View(bookings);
            }
            return View();
        }



        // GET: BookingsController/Details/5
        public async Task<IActionResult> GetBookingDetails(int? id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Bookings/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var book = JsonConvert.DeserializeObject<Booking>(jsondata);
                return View(book);
            }
            return NotFound();

        }

        // GET: AdminsController/Create
        public ActionResult AddBookingDetails()
        {
            return View();
        }

        // POST: AdminsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddBookingDetails(Booking book)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5294/api/Bookings", book);
            return RedirectToAction(nameof(Default));
        }

        // GET: AdminsController/Edit/5

        public async Task<IActionResult> UpdateBookingDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Bookings/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var book = JsonConvert.DeserializeObject<Booking>(jsondata);
                return View(book);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateBookingDetails(int id, Booking book)
        {
            if (id != book.BookingId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(book);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5294/api/Bookings/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(book);
        }
        // GET: AdminsController/Delete/5


        // POST: AdminsController/Delete/5
        public async Task<IActionResult> DeleteBookingDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Bookings/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var book = JsonConvert.DeserializeObject<Booking>(jsondata);
                return View(book);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteAdminDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5294/api/Bookings/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}
