﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;
namespace BookMyShow_MVC.Controllers
{
    public class TheatersController : Controller
    {
        private readonly HttpClient _httpClient;
        public TheatersController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5294/api/Theaters");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var theaters = JsonConvert.DeserializeObject<List<Theater>>(jsondata);
                return View(theaters);
            }
            return View();
        }
        // GET: TheatersController/Details/5
        public async Task<IActionResult> GetTheaterDetails(int? id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Theaters/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var t = JsonConvert.DeserializeObject<Theater>(jsondata);
                return View(t);
            }
            return NotFound();

        }

        // GET: AdminsController/Create
        public ActionResult AddAdminDetails()
        {
            return View();
        }

        // POST: AdminsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddTheaterDetails(Theater t)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5294/api/Theaters", t);
            return RedirectToAction(nameof(Default));
        }

        // GET: AdminsController/Edit/5

        public async Task<IActionResult> UpdateTheaterDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Theaters/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var t = JsonConvert.DeserializeObject<Theater>(jsondata);
                return View(t);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateTheaterDetails(int id, Theater t)
        {
            if (id != t.TheaterId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(t);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5294/api/Theaters/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(t);
        }
        // GET: AdminsController/Delete/5


        // POST: AdminsController/Delete/5
        public async Task<IActionResult> DeleteTheaterDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Theaters/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var t = JsonConvert.DeserializeObject<Theater>(jsondata);
                return View(t);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteAdminDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5294/api/Theaters/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}
