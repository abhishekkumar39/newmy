﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;
namespace BookMyShow_MVC.Controllers
{
    public class FeedbacksController : Controller
    {
        private readonly HttpClient _httpClient;
        public FeedbacksController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5294/api/Feedbacks");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var feedbacks = JsonConvert.DeserializeObject<List<Feedback>>(jsondata); ;
                return View(feedbacks);
            }
            return View();
        }

        // GET: FeedbacksController/Details/5
        public async Task<IActionResult> GetFeedbackDetails(int? id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Feedbacks/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var fb = JsonConvert.DeserializeObject<Feedback>(jsondata);
                return View(fb);
            }
            return NotFound();

        }

        // GET: AdminsController/Create
        public ActionResult AddFeedbackDetails()
        {
            return View();
        }

        // POST: AdminsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddFeedbackDetails(Feedback fb)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5294/api/Feedbacks", fb);
            return RedirectToAction(nameof(Default));
        }

        // GET: AdminsController/Edit/5

        public async Task<IActionResult> UpdateFeedbackDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Feedbacks/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var fb = JsonConvert.DeserializeObject<Feedback>(jsondata);
                return View(fb);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateFeedbackDetails(int id, Feedback fb)
        {
            if (id != fb.FeedbackId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(fb);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5294/api/Feedbacks/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(fb);
        }
        // GET: AdminsController/Delete/5


        // POST: AdminsController/Delete/5
        public async Task<IActionResult> DeleteFeedbackDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Feedbacks/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var fb = JsonConvert.DeserializeObject<Feedback>(jsondata);
                return View(fb);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteFeedbackDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5294/api/Feedbacks/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}
