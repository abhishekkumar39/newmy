﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;
namespace BookMyShow_MVC.Controllers
{
    public class CancellationsController : Controller
    {
        private readonly HttpClient _httpClient;
        public CancellationsController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5294/api/Cancellations");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var cancellations = JsonConvert.DeserializeObject<List<Cancellation>>(jsondata);
                return View(cancellations);
            }
            return View();
        }


        public async Task<IActionResult> GetCancellationsDetails(int? id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Cancellations/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var can = JsonConvert.DeserializeObject<Cancellation>(jsondata);
                return View(can);
            }
            return NotFound();

        }

        // GET: AdminsController/Create
        public ActionResult AddCancellationDetails()
        {
            return View();
        }

        // POST: AdminsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddCancellationDetails(Cancellation can)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5294/api/Cancellations", can);
            return RedirectToAction(nameof(Default));
        }

        // GET: AdminsController/Edit/5

        public async Task<IActionResult> UpdateCancellationDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Cancellations/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var can = JsonConvert.DeserializeObject<Cancellation>(jsondata);
                return View(can);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateCancellationDetails(int id, Cancellation can)
        {
            if (id != can.CancellationId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(can);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5294/api/Cancellations/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(can);
        }
        // GET: AdminsController/Delete/5


        // POST: AdminsController/Delete/5
        public async Task<IActionResult> DeleteCancellationDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Cancellations/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var can = JsonConvert.DeserializeObject<Cancellation>(jsondata);
                return View(can);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteCancellationDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5294/api/Cancellations/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}
