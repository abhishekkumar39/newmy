﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;
namespace BookMyShow_MVC.Controllers
{
    public class MoviesController : Controller
    {
        private readonly HttpClient _httpClient;
        public MoviesController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5294/api/Movies");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var movies = JsonConvert.DeserializeObject<List<Movie>>(jsondata);
                return View(movies);
            }
            return View();
        }
        // GET: MoviesController
        public async Task<IActionResult> GetMovieDetails(int? id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Movies/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var mv = JsonConvert.DeserializeObject<Movie>(jsondata);
                return View(mv);
            }
            return NotFound();

        }

        // GET: AdminsController/Create
        public ActionResult AddAdmiMovieDetails()
        {
            return View();
        }

        // POST: AdminsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddMovieDetails(Movie mv)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5294/api/Movies", mv);
            return RedirectToAction(nameof(Default));
        }

        // GET: AdminsController/Edit/5

        public async Task<IActionResult> UpdateMovieDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Movies/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var mv = JsonConvert.DeserializeObject<Movie>(jsondata);
                return View(mv);
            }
            return NotFound();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateMovieDetails(int id, Movie mv)
        {
            if (id != mv.MovieId)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(mv);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PutAsync($"http://localhost:5294/api/Movies/{id}", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(mv);
        }
        // GET: AdminsController/Delete/5


        // POST: AdminsController/Delete/5
        public async Task<IActionResult> DeleteMovieDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5294/api/Movies/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var mv = JsonConvert.DeserializeObject<Movie>(jsondata);
                return View(mv);
            }
            return NotFound();
        }

        [HttpPost, ActionName("DeleteMovieDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5294/api/Movies/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}
