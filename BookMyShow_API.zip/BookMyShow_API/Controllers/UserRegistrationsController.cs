﻿using BookMyShow_DAO;

using Microsoft.AspNetCore.Mvc;

using Microsoft.EntityFrameworkCore;


namespace BookMyShow_API.Controllers

{

    [Route("api/[controller]")]

    [ApiController]

    public class UserRegistrationsController : ControllerBase

    {

        private readonly BookMyShowDbContext _context;

        public UserRegistrationsController(BookMyShowDbContext context)

        {

            _context = context;

        }


        [HttpGet]

        public IEnumerable<UserRegistration> GetUserRegistrations()

        {

            return _context.UserRegistrations.ToList();

        }


        [HttpGet("{id}")]

        public UserRegistration GetUserRegistration(int id)

        {

            var ur = _context.UserRegistrations.Find(id);

            if (ur == null)

            {

                return new UserRegistration();

            }

            return ur;

        }


        [HttpPost]

        public void PostUserRegistrations([FromBody] UserRegistration ur)

        {

            _context.UserRegistrations.Add(ur);

            _context.SaveChanges();

        }


        [HttpPut("{id}")]

        public void PutUserRegistrations(int id, [FromBody] UserRegistration ur)

        {

            _context.Entry(ur).State = EntityState.Modified;

            _context.SaveChanges();

        }


        [HttpDelete("{id}")]

        public bool DeleteUserRegistrations(int id)

        {

            var ur = _context.UserRegistrations.Find(id);

            if (ur == null)

            {

                return false;

            }

            _context.UserRegistrations.Remove(ur);

            _context.SaveChanges();

            return true;

        }

    }

}