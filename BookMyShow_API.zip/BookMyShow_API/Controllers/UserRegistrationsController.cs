﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BookMyShow_DAO;
namespace BookMyShow_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserRegistrationsController : ControllerBase
    {
        private readonly BookMyShowDbContext _context;

        public UserRegistrationsController(BookMyShowDbContext context)
        {
            _context = context;
        }
        // GET: api/<AdminsController>
        [HttpGet]
        public IEnumerable<UserRegistration> GetUserRegistrations()
        {
            return _context.UserRegistrations.ToList();
        }

        [HttpGet("{id}")]
        public ActionResult<UserRegistration> GetUserRegistration(int id)
        {
            var user = _context.UserRegistrations.FirstOrDefault(m => m.UserRegistrationId == id);
            if (user == null)
            {
                return NotFound();
            }
            return user;
        }


        [HttpGet("{username}/{password}")]
        public ActionResult<UserRegistration> GetUserRegistration(string username, string password)
        {
            var user = _context.UserRegistrations.FirstOrDefault(m => (m.UserName == username && m.Password == password));
            if (user == null)
            {
                return NotFound();
            }
            return user;
        }

        [HttpPost]
        public ActionResult<UserRegistration> PostUserRegistration([FromBody] UserRegistration user)
        {
            _context.UserRegistrations.Add(user);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetUserRegistration), new { id = user.UserRegistrationId }, user);
        }

        [HttpPut("{id}")]
        public IActionResult PutUserRegistration(int id, [FromBody] UserRegistration user)
        {
            if (id != user.UserRegistrationId)
            {
                return BadRequest();
            }

            _context.Entry(user).State = EntityState.Modified;
            _context.SaveChanges();

            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteUserRegistration(int id)
        {
            var user = _context.UserRegistrations.Find(id);
            if (user == null)
            {
                return NotFound();
            }

            _context.UserRegistrations.Remove(user);
            _context.SaveChanges();

            return NoContent();
        }
    }
}