﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookMyShow_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CancellationsController : ControllerBase
    {
        private readonly BookMyShowDbContext _context;
        public CancellationsController(BookMyShowDbContext context)
        {
            _context = context;
        }
        // GET: api/<MoviesController>
        [HttpGet]
        public IEnumerable<Cancellation> GetCancellations()
        {
            return _context.Cancellations.ToList();
        }

        // GET api/<MoviesController>/5
        [HttpGet("{id}")]
        public Cancellation GetCancellation(int id)
        {
            var cancel = _context.Cancellations.Find(id);

            if (cancel == null)
            {
                return new Cancellation();
            }
            return cancel;
        }

        // POST api/<MoviesController>
        [HttpPost]
        public void PostCancellation([FromBody] Cancellation cancel)
        {
            _context.Cancellations.Add(cancel);
            _context.SaveChanges();
        }

        // PUT api/<MoviesController>/5
        [HttpPut("{id}")]
        public void PutCancellation(int id, [FromBody] Cancellation cancel)
        {
            _context.Entry(cancel).State = EntityState.Modified;
            _context.SaveChanges();
        }

        // DELETE api/<MoviesController>/5
        [HttpDelete("{id}")]
        public bool DeleteCancellation(int id)
        {
            var cancel = _context.Cancellations.Find(id);
            if (cancel == null)
            {
                return false;
            }

            _context.Cancellations.Remove(cancel);
            _context.SaveChanges();
            return true;
        }
    }
}