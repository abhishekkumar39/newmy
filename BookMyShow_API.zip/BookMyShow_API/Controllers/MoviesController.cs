﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookMyShow_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        private readonly BookMyShowDbContext _context;
        public MoviesController(BookMyShowDbContext context)
        {
            _context = context;
        }
        // GET: api/<MoviesController>
        [HttpGet]
        public IEnumerable<Movie> GetMovies()
        {
            return _context.Movies.ToList();
        }

        // GET api/<MoviesController>/5
        [HttpGet("{id}")]
        public Movie GetMovie(int id)
        {
            var mov = _context.Movies.Find(id);

            if (mov == null)
            {
                return new Movie();
            }
                return mov;
        }

        // POST api/<MoviesController>
        [HttpPost]
        public void PostMovie([FromBody] Movie mov)
        {
            _context.Movies.Add(mov);
            _context.SaveChanges();
        }

        // PUT api/<MoviesController>/5
        [HttpPut("{id}")]
        public void PutMovie(int id, [FromBody] Movie mov)
        {
            _context.Entry(mov).State = EntityState.Modified;
            _context.SaveChanges();
        }

        // DELETE api/<MoviesController>/5
        [HttpDelete("{id}")]
        public bool DeleteMovie(int id)
        {
            var mov = _context.Movies.Find(id);
            if (mov == null)
            {
                return false;
            }

            _context.Movies.Remove(mov);
            _context.SaveChanges();
            return true;
        }
    }
}
