﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookMyShow_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TheatersController : ControllerBase
    {
        private readonly BookMyShowDbContext _context;
        public TheatersController(BookMyShowDbContext context)
        {
            _context = context;
        }
        // GET: api/<TheatersController>
        [HttpGet]
        public IEnumerable<Theater> GetTheaters()
        {
            return _context.Theaters.ToList();
        }

        // GET api/<TheatersController>/5
        [HttpGet("{id}")]
        public Theater GetTheater(int id)
        {
            var th = _context.Theaters.Find(id);

            if (th == null)
            {
                return new Theater();
            }
            return th;
        }

        // POST api/<TheatersController>
        [HttpPost]
        public void PostTheater([FromBody] Theater th)
        {
            _context.Theaters.Add(th);
            _context.SaveChanges();
        }

        // PUT api/<TheatersController>/5
        [HttpPut("{id}")]
        public void PutTheater(int id, [FromBody] Theater th)
        {
            _context.Entry(th).State = EntityState.Modified;
            _context.SaveChanges();
        }

        // DELETE api/<TheatersController>/5
        [HttpDelete("{id}")]
        public bool DeleteTheater(int id)
        {
            var th = _context.Theaters.Find(id);
            if (th == null)
            {
                return false;
            }

            _context.Theaters.Remove(th);
            _context.SaveChanges();
            return true;
        }
    }
}