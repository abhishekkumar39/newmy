﻿using BookMyShow_DAO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookMyShow_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FeedbacksController : ControllerBase
    {
        private readonly BookMyShowDbContext _context;
        public FeedbacksController(BookMyShowDbContext context)
        {
            _context = context;
        }
        // GET: api/<FeedbacksController>
        [HttpGet]
        public IEnumerable<Feedback> GetFeedbacks()
        {
            return _context.Feedbacks.ToList();
        }

        // GET api/<FeedBacksController>/5
        [HttpGet("{id}")]
        public Feedback GetFeedback(int id)
        {
            var fb = _context.Feedbacks.Find(id);

            if (fb == null)
            {
                return new Feedback();
            }
            return fb;
        }

        // POST api/<FeedbacksController>
        [HttpPost]
        public void PostFeedback([FromBody] Feedback fb)
        {
            _context.Feedbacks.Add(fb);
            _context.SaveChanges();
        }

        // PUT api/<FeedbacksController>/5
        [HttpPut("{id}")]
        public void PutFeedback(int id, [FromBody] Feedback fb)
        {
            _context.Entry(fb).State = EntityState.Modified;
            _context.SaveChanges();
        }

        // DELETE api/<FeedbacksController>/5
        [HttpDelete("{id}")]
        public bool DeleteFeedback(int id)
        {
            var fb = _context.Feedbacks.Find(id);
            if (fb == null)
            {
                return false;
            }

            _context.Feedbacks.Remove(fb);
            _context.SaveChanges();
            return true;
        }
    }
}