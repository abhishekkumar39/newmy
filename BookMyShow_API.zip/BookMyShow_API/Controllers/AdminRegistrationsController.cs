﻿using BookMyShow_DAO;

using Microsoft.AspNetCore.Mvc;

using Microsoft.EntityFrameworkCore;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BookMyShow_API.Controllers

{

    [Route("api/[controller]")]

    [ApiController]

    public class AdminRegistrationsController : ControllerBase

    {

        private readonly BookMyShowDbContext _context;

        public AdminRegistrationsController(BookMyShowDbContext context)
        {
            _context = context;
        }
        // GET: api/<AdminsController>
        [HttpGet]
        public IEnumerable<AdminRegistration> GetAdminRegistrations()
        {
            return _context.AdminRegistrations.ToList();
        }

        // GET api/<AdminsController>/5
        [HttpGet("{id}")]
        public AdminRegistration? GetAdminRegistration(int id)
        {
            var admin = _context.AdminRegistrations.FirstOrDefault(m => m.AdminRegistrationId == id);
            return admin;
        }
        [HttpGet("{username}/{password}")]
        public ActionResult<AdminRegistration> GetAdminRegistration(string username, string password)
        {
            var admin = _context.AdminRegistrations.FirstOrDefault(m => (m.AdminName == username && m.Password == password));
            if (admin == null)
            {
                return NotFound();
            }
            return admin;
        }
        // POST api/<AdminsController>
        [HttpPost]
        public void PostAdminRegistration([FromBody] AdminRegistration admin)
        {
            _context.AdminRegistrations.Add(admin);
            _context.SaveChanges();
        }

        // PUT api/<AdminsController>/5
        [HttpPut("{id}")]
        public void PutAdminRegistration(int id, [FromBody] AdminRegistration admin)
        {
            if (ModelState.IsValid)
            {
                _context.Update(admin);
                _context.SaveChanges();
            }
        }

        // DELETE api/<AdminsController>/5
        // DELETE api/<AdminsController>/5
        [HttpDelete("{AdminRegistrationId}")]
        public void DeleteAdmin(int AdminRegistrationId)
        {
            var admin = _context.AdminRegistrations.Find(AdminRegistrationId);
            if (admin != null)
            {
                _context.AdminRegistrations.Remove(admin);
                _context.SaveChanges();
            }
        }
    }
}